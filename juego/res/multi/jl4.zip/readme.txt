This example map adds to jl1 a third resource: stone.
Press shift + Z to check how much stone you have.
